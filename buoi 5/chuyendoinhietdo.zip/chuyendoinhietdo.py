#laydulieutu thu vien
import math
#nhap gia tri nhiet do 
C = float(input("Nhap nhiet do vao: "))
#doi gia tri 
F = ((C * 1.8) + 32)
#in ra man hinh 
print ("Nhiet do sau khi doi la: ",F, "°F")